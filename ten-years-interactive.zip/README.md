# A decade of trade — real CITES data

A single-screen chapter for scalloped hammerhead (*Sphyrna lewini*) trade, 2015–2024. Two views share a fixed single-screen layout, English interface and continuous scroll/playback animation: Annual quantity, then Product forms. The default view now loads a frozen official CITES extract; there is no synthetic-data fallback.

## Design update

See the [project design standard](design/DESIGN-STANDARD.md) for the approved palette, typography scale, bundled fonts and original references.

The chapter follows the supplied Abyssal Bloom palette: abyssal black background, deep blue surfaces, cobalt controls, cyan chart highlights, silver text, and restrained copper policy markers. Manrope headings and Inter body copy follow the supplied responsive type scale. Manrope Medium 500 and Inter Regular 400 / Medium 500 are bundled locally, together with their SIL Open Font Licenses; no font network request is required. The supplied desktop/mobile scales are H1 96/44, H2 48/32, H3 28/24, lead 20/18, body 18/16, captions 14/14 and buttons 16/16 px. Chart marks and dialogs use the same scoped theme tokens.

Desktop, mobile and short layouts stay fixed to the chapter container; wheel/touch explore time instead of scrolling the document. Only dialogs scroll internally. Compact chapter title/data-label sizes adapt to available height; bundled typography and palette tokens remain in use.

## Preview

Open `dist/index.html` directly, or run:

```sh
python3 -m http.server 8765 --directory dist
```

Scroll down/up to move continuously through two scenes. Global progress 0–9 explores annual quantities, 9–11 crossfades to Product forms, and 11–20 explores product forms. The year fades out during the scroll transition and resets to 2015 in the second view; reversing retraces the transition. Releasing at the exact transition midpoint completes toward the scrolling direction. View buttons crossfade while preserving the selected year; year buttons/arrows remain local to the active view. Touch movement follows the same timeline. On release, motion settles smoothly to a nearby year. Year buttons, arrow keys and playback remain available. Annual figures remain actual year totals; animation positions do not create additional observed quantities. Missing intervals are not connected.

## Official source

CITES Trade Database (2026). Compiled by UNEP-WCMC for the CITES Secretariat. Available at [trade.cites.org](https://trade.cites.org/en/cites_trade). Accessed **4 November 2026**.

- Source: live-query **comparative tabulation** (`comptab`), not the static full shipment database.
- Accepted taxon: *Sphyrna lewini*, official taxon ID **6544**.
- Query: 2015–2024, all countries, sources, purposes and terms. The exact download URL is in `dist/data/provenance.json`.
- Official response: **41,814 bytes, 399 comparative rows**. The original file is retained unmodified.
- SHA-256: `a06c0cc08b405945bc72d66b96b2d2076c3027589b9b5412b4a73dcf62895586`.
- This is a live-query snapshot accessed in 2026, **not** labelled as the static 2026.1 database release. Later downloads can differ as reports are updated.

The official [interpretation guide](https://trade.cites.org/cites_trade_guidelines/en-CITES_Trade_Database_Guide.pdf) explains comparative aggregation, reporting-side differences, units and re-exports. These are essential to interpreting the numbers.

## Displayed scope

Default: **fins (FIN), kg, exporter-reported, all sources**.

The Filters panel offers three separate fin products:

| Official term | Code | Handling |
| --- | --- | --- |
| fins | FIN | Default series |
| fin (dried) | DFN | Separate series |
| fin (wet) | FFN | Separate series |

These products are never summed. The frozen extract first records DFN in 2022 and FFN in 2024. This does not establish the introduction date of a code or the start of that trade. A change in FIN alone does not describe all fin forms.

Only rows explicitly reported in **kg** and Appendix I–III are retained; all retained rows happen to be Appendix II. Other units are excluded, not converted. Of 245 fin-product comparative rows:

- 146 kg rows are retained.
- 64 blank-unit, 33 “Number of specimens”, one g and one cm³ row are excluded.
- The other 154 rows in the original extract concern non-fin terms and are excluded.

Importer and exporter quantity columns are split into independent records, producing **194 reporting-side rows** across all three fin products (103 exporter, 91 importer). Blank side quantities are omitted, not zero-filled. Numeric zero remains zero. Main figures and CSV exports use a fixed reporting side; the two sides are never added.

The table's **Data rows** count refers to non-missing comparative groups on the selected reporting side. It is **not** a count of original reports, transactions, shipments or animals. Direct trade and re-exports are included; quantities do not represent unique animals or harvest. All purposes and sources are included by default, including any confiscated/seized-source entries. Wild-only filtering selects source W.

## Default FIN annual audit, kg

| Year | Exporter-reported | Importer-reported |
| --- | ---: | ---: |
| 2015 | 7,302.970 | 7,741.310 |
| 2016 | 15,622.920 | 9,119.710 |
| 2017 | 14,410.170 | 5,827.510 |
| 2018 | 6,253.550 | 2,934.300 |
| 2019 | 8,177.660 | 6,993.400 |
| 2020 | 14,248.061 | 11,759.210 |
| 2021 | 43,126.301 | 18,792.320 |
| 2022 | 28,909.014 | 2,765.160 |
| 2023 | 18,241.690 | 1,953.244 |
| 2024 | 10,513.760 | 79.200 |

Differences between the sides are retained. The latest year's small importer total must not be interpreted as total trade or conservation improvement. Coverage and quantities may change with subsequent reporting. No population comparison or effectiveness claim is made.

## Reproducibility and files

- `data/raw/cites-sphyrna-lewini-2015-2024-comptab.csv`: original official extract.
- `data/raw/cites-response-headers.txt`: response headers, including byte length and timestamp.
- `data/raw/cites-sphyrna-lewini-taxon.json`, `cites-trade-terms.json`: official taxon and term lookups.
- `scripts/build_cites_dataset.py`: filters the frozen extract, splits reporting sides, uses Decimal for annual audit totals and generates browser assets. Rejects a changed original checksum.
- `scripts/verify_cites_dataset.cjs`: verifies the source checksum, all 120 annual product/source/side aggregates and counts, known FIN totals, missing vs zero, normalized CSV roundtrip, and absence of a demo generator.
- `dist/data/cites-fins-2015-2024.js`: bundled real records; works without network access or a server.
- `dist/data/cites-fins-2015-2024.csv`: normalized reporting-side records, including original quantities and original comparative CSV row numbers.
- `dist/data/annual-audit.json`: exact Decimal-derived annual totals.
- `dist/data/provenance.json`: source URLs, scope, exclusions and checksum.
- `dist/data/cites-sphyrna-lewini-2015-2024-comptab.csv`: downloadable copy of the unmodified official extract.

```sh
python3 scripts/build_cites_dataset.py
node scripts/verify_cites_dataset.cjs
```

## Integration

Load `style.css`, `data.js`, `data/cites-fins-2015-2024.js`, `data/cites-management-events.js`, `motion.js`, then `app.js`. Provide a container with an explicit height and call:

```js
const chapter = MarineDecade.mount(container, { releaseAtBoundary: true });
chapter.setYear(2021); // smooth year transition in the current view
chapter.setView('forms'); // crossfade, preserving the current selected year
chapter.play();
chapter.pause();
chapter.getState(); // year, view, local position/targetPosition, global progress/targetProgress, transitioning, filters, playing
chapter.destroy();
```

Styles are scoped to `.dv-shell`. Do not copy the standalone body class into the host project. Wheel and keyboard listeners remain local to the chapter. `decade:year-change`, `decade:view-change` and `decade:boundary` events allow chapter coordination. Optional `wheelPixelsPerYear` (180) and `playInterval` (1,400 ms/year) tune motion. Reduced-motion preferences disable reels, crossfades and cursor interpolation; the scroll transition advances directly between views. `mount(container, {view:'forms', year:2024})` can initialize the second scene. Playback traverses both scenes and ends at Product forms 2024; replay there restarts Annual quantity 2015. Pausing, filter interaction or opening a dialog stops playback. The host receives boundary events only at the beginning/end of the entire scroll sequence.

CSV replacement imports remain browser-local. They must use the normalized template with `Year,Quantity,Unit,Term,Reporter.type,Taxon,Importer,Exporter,Source,Appendix`; use the official term labels above. Imported files are labelled separately and the bundled provenance panel is hidden to avoid attributing a replacement file to this frozen extract.

Six selected management records are bundled in `dist/data/cites-management-events.json` and its browser JS equivalent. See [EVENTS.md](EVENTS.md) for verification and exclusions. They display at corresponding years, with source links and a scope/date details dialog. The policy row reserves its height to keep scroll animation and chart geometry stable. National measures remain contextual; they do not create lines or quantitative thresholds on the global curve. Reviews are explicitly not bans. No events are invented for empty years.

`setEvents()` accepts the existing exact-filter schema or the bundled context schema. Provider imports replace the event register and are not independently verified. Context events require `verified`, exact taxon, year list, product list, safe source URLs, title, scope, date and type. A year-only date remains a year; no first-of-January default is invented. Legacy events are also displayed only as context; their filter labels are not proof of geographic applicability.


## Product forms and verification

Product forms now uses three directly labelled horizontal bars for the selected year, on one linear kg scale fixed across all ten years and products for the selected reporting side/source. Scrolling changes the year and bar lengths. It does not sum products, compute composition percentages or imply equal biomass. Fins (FIN) is displayed as “Fins, unspecified (FIN)” to distinguish it from the explicit dried/wet terms. Missing years show “No records” and a dashed empty baseline, while reported zero remains 0 kg. The scale changes only with shared filters or data replacement.

Numeric labels are actual annual totals. Bar lengths interpolate only between adjacent observed quantities; an isolated record fades in at its reported weight instead of growing from an invented zero. Reduced motion shows the annual state directly.

With default exporter/all-source filters, DFN has records in 2023–2024 (6,279.61 and 7,178.61 kg), and FFN has one in 2024 (1,313 kg). Importer DFN records begin in 2022. The direct bar labels, full 30-row data table and filtered CSV show each product separately; all share the current reporting side/source. Annual quantity retains its selected single product when returning from Product forms. Product selection is hidden in the forms view.

Policy events are shared contextual cards in both views; forms matches events relevant to any of the three products. They do not add global restriction lines or quota thresholds. The row retains its geometry and becomes non-interactive during transitions. Source references and scope/date dialogs are unchanged.

Run `node scripts/verify_motion.cjs` in addition to the two existing verification scripts. It checks the two-scene mapping, reversible transitions, year bounds, reduced-motion snapping, release direction and missing-data cursor behavior. Browser QA covers both scenes, shared filters, preserved years, policy pagination/details, playback, forward/reverse wheel transitions and 1280×720, 390×844, 375×667 and phone-landscape layouts.


## Transition refinement

Scene blending now uses a quintic easing envelope. Scroll resets fade 2024 out with a restrained upward drift, replace it only inside a fully transparent central interval, and fade 2015 in from below. The reverse scroll follows the same envelope. Chart captions and policy context follow the reset fade; direct view switches preserve the year and crossfade over 600 ms.

Policy content has a separate phase inside the existing animation clock: 120 ms out, replace text at zero opacity, then 220 ms in. Rapid year/page requests coalesce to the most recent content, including empty years. Outgoing or near-invisible links remain inert. No new timer, decorative overlay or layout movement is introduced. Reduced-motion skips these effects. `node scripts/verify_policy_motion.cjs` verifies replacement timing, rapid requests, empty years and reduced motion; `verify_motion.cjs` also checks the invisible reset interval and forward/reverse symmetry.


## Clear controls

The two views are numbered and named. Previous, Play/Pause/Replay and Next have visible text alongside their icons. Year buttons retain the active-year underline/background; hovering over another year no longer resembles selection. Playback still uses the same clock and the reset/policy fade behavior above. Compact mobile layouts retain all controls and the fixed single screen. Asset query versions prevent the local preview reusing a previous chart script/style after this update.
